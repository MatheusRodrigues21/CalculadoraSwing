import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class CalculadoraSimples extends JFrame {
    private JTextField txtNumero1;
    private JTextField txtNumero2;
    private JLabel lblResultado;
    private JLabel lblOperacao;
    private JButton btnSomar;
    private JButton btnSubtrair;
    private JButton btnMultiplicar;
    private JButton btnDividir;
    private JButton btnLimpar;
    private String operacaoAtual = "";

    public CalculadoraSimples() {
        // Configurações da janela
        setTitle("Calculadora");
        setSize(420, 580);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setUndecorated(false);

        // Painel principal com fundo moderno
        JPanel painelPrincipal = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth();
                int h = getHeight();
                Color cor1 = new Color(32, 32, 36);
                Color cor2 = new Color(24, 24, 27);
                GradientPaint gp = new GradientPaint(0, 0, cor1, 0, h, cor2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        painelPrincipal.setLayout(null);

        // Título da calculadora
        JLabel lblTitulo = new JLabel("CALCULADORA");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitulo.setForeground(new Color(150, 150, 150));
        lblTitulo.setBounds(25, 15, 200, 20);
        painelPrincipal.add(lblTitulo);

        // Display principal - estilo iOS/Android moderno
        JPanel painelDisplay = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(40, 40, 44));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);

                // Borda sutil com brilho
                g2d.setColor(new Color(60, 60, 65));
                g2d.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
            }
        };
        painelDisplay.setLayout(null);
        painelDisplay.setBounds(25, 50, 370, 180);
        painelDisplay.setOpaque(false);

        // Label de operação no topo do display
        lblOperacao = new JLabel("", SwingConstants.RIGHT);
        lblOperacao.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblOperacao.setForeground(new Color(120, 120, 125));
        lblOperacao.setBounds(20, 15, 330, 25);
        painelDisplay.add(lblOperacao);

        // Campos de entrada estilizados
        txtNumero1 = criarCampoModerno();
        txtNumero1.setBounds(20, 50, 330, 45);
        painelDisplay.add(txtNumero1);

        txtNumero2 = criarCampoModerno();
        txtNumero2.setBounds(20, 105, 330, 45);
        painelDisplay.add(txtNumero2);

        painelPrincipal.add(painelDisplay);

        // Display de resultado
        JPanel painelResultado = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Fundo com gradiente sutil
                GradientPaint gp = new GradientPaint(0, 0, new Color(28, 28, 30), 0, getHeight(), new Color(18, 18, 20));
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);

                // Brilho no topo
                g2d.setColor(new Color(50, 50, 55, 80));
                g2d.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
            }
        };
        painelResultado.setLayout(null);
        painelResultado.setBounds(25, 250, 370, 100);
        painelResultado.setOpaque(false);

        JLabel lblTextoResultado = new JLabel("RESULTADO");
        lblTextoResultado.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblTextoResultado.setForeground(new Color(100, 100, 105));
        lblTextoResultado.setBounds(20, 12, 100, 15);
        painelResultado.add(lblTextoResultado);

        lblResultado = new JLabel("0", SwingConstants.RIGHT);
        lblResultado.setFont(new Font("Segoe UI", Font.BOLD, 42));
        lblResultado.setForeground(new Color(10, 132, 255));
        lblResultado.setBounds(20, 30, 330, 55);
        painelResultado.add(lblResultado);

        painelPrincipal.add(painelResultado);

        // Painel de botões com layout em grade
        int startY = 370;
        int btnWidth = 110;
        int btnHeight = 65;
        int spacing = 15;

        // Primeira linha
        btnSomar = criarBotaoModerno("+", new Color(0, 122, 255));
        btnSomar.setBounds(25, startY, btnWidth, btnHeight);
        painelPrincipal.add(btnSomar);

        btnSubtrair = criarBotaoModerno("−", new Color(0, 122, 255));
        btnSubtrair.setBounds(25 + btnWidth + spacing, startY, btnWidth, btnHeight);
        painelPrincipal.add(btnSubtrair);

        btnMultiplicar = criarBotaoModerno("×", new Color(0, 122, 255));
        btnMultiplicar.setBounds(25 + (btnWidth + spacing) * 2, startY, btnWidth, btnHeight);
        painelPrincipal.add(btnMultiplicar);

        // Segunda linha
        btnDividir = criarBotaoModerno("÷", new Color(0, 122, 255));
        btnDividir.setBounds(25, startY + btnHeight + spacing, btnWidth, btnHeight);
        painelPrincipal.add(btnDividir);

        btnLimpar = criarBotaoModerno("LIMPAR", new Color(255, 59, 48));
        btnLimpar.setBounds(25 + btnWidth + spacing, startY + btnHeight + spacing, (btnWidth * 2) + spacing, btnHeight);
        painelPrincipal.add(btnLimpar);

        add(painelPrincipal);

        // Eventos dos botões
        btnSomar.addActionListener(e -> calcular('+'));
        btnSubtrair.addActionListener(e -> calcular('-'));
        btnMultiplicar.addActionListener(e -> calcular('×'));
        btnDividir.addActionListener(e -> calcular('÷'));
        btnLimpar.addActionListener(e -> limpar());
    }

    private JTextField criarCampoModerno() {
        JTextField campo = new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Fundo
                g2d.setColor(new Color(28, 28, 30));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);

                // Borda quando focado
                if (isFocusOwner()) {
                    g2d.setColor(new Color(0, 122, 255, 100));
                    g2d.setStroke(new BasicStroke(2));
                    g2d.drawRoundRect(1, 1, getWidth()-2, getHeight()-2, 12, 12);
                }

                super.paintComponent(g);
            }
        };

        campo.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        campo.setHorizontalAlignment(JTextField.CENTER);
        campo.setForeground(new Color(255, 255, 255));
        campo.setCaretColor(new Color(0, 122, 255));
        campo.setOpaque(false);
        campo.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        return campo;
    }

    private JButton criarBotaoModerno(String texto, Color cor) {
        JButton btn = new JButton(texto) {
            private boolean pressionado = false;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Sombra
                g2d.setColor(new Color(0, 0, 0, 40));
                g2d.fillRoundRect(2, 4, getWidth()-4, getHeight()-2, 18, 18);

                // Fundo do botão com efeito de profundidade
                Color corFundo = cor;
                if (getModel().isRollover() && !pressionado) {
                    corFundo = cor.brighter();
                } else if (pressionado) {
                    corFundo = cor.darker();
                }

                GradientPaint gp = new GradientPaint(0, 0, corFundo, 0, getHeight(), corFundo.darker());
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight()-2, 18, 18);

                // Brilho no topo
                g2d.setColor(new Color(255, 255, 255, 30));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight()/2, 18, 18);

                super.paintComponent(g);
            }
        };

        btn.setFont(new Font("Segoe UI", Font.BOLD, texto.length() > 2 ? 16 : 28));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Efeito de pressionar
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn.putClientProperty("pressionado", true);
                btn.repaint();
            }

            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btn.putClientProperty("pressionado", false);
                btn.repaint();
            }
        });

        return btn;
    }

    private void calcular(char operacao) {
        try {
            double num1 = Double.parseDouble(txtNumero1.getText().replace(",", "."));
            double num2 = Double.parseDouble(txtNumero2.getText().replace(",", "."));
            double resultado = 0;

            operacaoAtual = String.format("%.2f %c %.2f", num1, operacao, num2);
            lblOperacao.setText(operacaoAtual);

            switch (operacao) {
                case '+':
                    resultado = num1 + num2;
                    break;
                case '-':
                    resultado = num1 - num2;
                    break;
                case '×':
                    resultado = num1 * num2;
                    break;
                case '÷':
                    if (num2 == 0) {
                        lblResultado.setText("Erro: Divisão por zero");
                        lblResultado.setForeground(new Color(255, 59, 48));
                        lblResultado.setFont(new Font("Segoe UI", Font.BOLD, 20));
                        return;
                    }
                    resultado = num1 / num2;
                    break;
            }

            // Formatar resultado
            lblResultado.setFont(new Font("Segoe UI", Font.BOLD, 42));
            if (resultado == (long) resultado && Math.abs(resultado) < 1000000) {
                lblResultado.setText(String.format("%,d", (long) resultado));
            } else {
                lblResultado.setText(String.format("%,.2f", resultado));
            }
            lblResultado.setForeground(new Color(10, 132, 255));

        } catch (NumberFormatException ex) {
            lblOperacao.setText("Entrada inválida");
            lblResultado.setText("---");
            lblResultado.setForeground(new Color(255, 59, 48));
        }
    }

    private void limpar() {
        txtNumero1.setText("");
        txtNumero2.setText("");
        lblResultado.setText("0");
        lblOperacao.setText("");
        lblResultado.setFont(new Font("Segoe UI", Font.BOLD, 42));
        lblResultado.setForeground(new Color(10, 132, 255));
        txtNumero1.requestFocus();
        operacaoAtual = "";
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            CalculadoraSimples calculadora = new CalculadoraSimples();
            calculadora.setVisible(true);
        });
    }
}